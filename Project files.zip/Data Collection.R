rm(list=ls()); cat("\014") # clear all


library(rvest)

url_list <- c("http://uselectionatlas.org/RESULTS/data.php?year=2020&datatype=national&def=1&f=0&off=0&elect=0",
         "http://uselectionatlas.org/RESULTS/data.php?year=2016&datatype=national&def=1&f=0&off=0&elect=0")

webc <- rvest::read_html(url_list[1])
webc %>% 
  html_element("td") %>% 
  html_table() -> Results_2020  
write.csv(Results_2020, file = "2020.csv")


webc <- rvest::read_html(url_list[2])
webc %>% 
  html_element("td") %>% 
  html_table() -> Results_2016  
write.csv(Results_2016, file = "2016.csv")

##add to csv list created from StateLevelData.xlsx